import { Component } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-qbtkt-modal-ngaydi',
  templateUrl: 'qbtkt-modal-ngaydi.html',
})
export class QBTicketingModalNgayDi {

  constructor(
    private navCtrl: NavController
  ) {

  }

}
