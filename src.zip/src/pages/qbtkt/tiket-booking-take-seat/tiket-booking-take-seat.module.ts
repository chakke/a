import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TiketBookingTakeSeatPage } from './tiket-booking-take-seat';

@NgModule({
  declarations: [
    TiketBookingTakeSeatPage,
  ],
  imports: [
    IonicPageModule.forChild(TiketBookingTakeSeatPage),
  ],
})
export class TiketBookingTakeSeatPageModule {}
