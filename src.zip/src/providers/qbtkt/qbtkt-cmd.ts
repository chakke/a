export class QBTicketingCmd {

   
}