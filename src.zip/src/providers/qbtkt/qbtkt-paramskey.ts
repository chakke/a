export class QBTicketingParamsKey {

   
    public static PASSWORD: string = "password";
    
    public static USERNAME: string = "username";

    


}