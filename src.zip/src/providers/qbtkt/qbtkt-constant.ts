export class QbtktConstant{
    public NORMAL: number = 0;
    public UNAVAILABLE: number = -1;
    public TODAY: number = 1;
    public DEPARTURE: number = 2;
    public RETURN: number = 3;
    public ONTRIP: number = 4;

    constructor(){

    }
}