export class GoogleUser {
    id: string;
    displayname: string;
    givenname: string;
    familyname: string;
    avatar: string;
    cover: string;
    status: number;
}