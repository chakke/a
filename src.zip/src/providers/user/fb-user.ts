export class FacebookUser {
    id: string;
    name: string;
    avatar: string;
    cover: string;
    accesstoken : string;
    expiredIn : number;
    status : number;
}