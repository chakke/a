export class StringItem {
    id: number = -1;
    name: string = "";
}