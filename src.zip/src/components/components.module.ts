// import { NgModule } from '@angular/core';
// import { ImageCardComponent } from './image-card/image-card';
// @NgModule({
// 	declarations: [ImageCardComponent],
// 	imports: [],
// 	exports: [ImageCardComponent]
// })
// export class ComponentsModule {}
